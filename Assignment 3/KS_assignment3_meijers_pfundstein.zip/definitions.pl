%% Kennissystemen 2014-2015
%% Assignment 3 - MC4
%% Markus Pfundstein (10452397)
%% Thomas Meijers (10647023)
%%
%% Definitions

/*
 * Defining new operators
 */

:- op(800, fx, if).
:- op(700, xfx, then).
:- op(700, xfx, ask).
:- op(300, xfy, or).
:- op(200, xfy, and).

:- dynamic(fact/1).